# shock-baileys-wa-nozzy

Bot WhatsApp memakai Baileys mod:
`github:RopzTyz/BaileysRopz`

## Cara Install

```
git clone https://github.com/USERNAME/shock-baileys-wa-nozzy
cd shock-baileys-wa-nozzy
npm install
npm start
```

QR akan muncul otomatis di terminal.
